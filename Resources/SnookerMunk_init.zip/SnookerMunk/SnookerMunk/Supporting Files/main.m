//
//  main.m
//  SnookerMunk
//
//  Created by Jorge Jordán Arenas on 10/08/14.
//  Copyright Your Company 2014. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
