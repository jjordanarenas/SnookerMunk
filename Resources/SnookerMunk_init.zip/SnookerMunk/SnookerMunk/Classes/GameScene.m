#import "GameScene.h"


@implementation GameScene {
    
}

+ (GameScene *)scene
{
	return [[self alloc] init];
}

// -----------------------------------------------------------------------

- (id)init
{
    // Apple recommend assigning self with supers return value
    self = [super init];
    if (!self) return(nil);
    
    return self;
}
@end
