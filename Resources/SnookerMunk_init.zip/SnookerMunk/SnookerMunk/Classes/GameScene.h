#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface GameScene : CCScene {
    
}

+ (GameScene *)scene;
- (id)init;

@end
